import { afterEach, describe, expect, it, vi } from 'vitest'
import tts, { pickVoice, VOICES } from '../netlify/functions/tts'

const post = (url: string, body: unknown) => new Request(`http://localhost${url}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
const ctx = (ip: string) => ({ ip })
describe('Netlify function tts (stubbed upstream; the real Google API was NOT called)', () => {
  it('not configured without key', async () => { expect((await tts(post('/api/tts', { text: '你好', gender: 'male' }), ctx('2.2.2.1'))).status).toBe(501) })
  it('rejects text that is not Chinese or too long', async () => {
    process.env.GOOGLE_TTS_API_KEY = 'k'
    expect((await tts(post('/api/tts', { text: 'hello' }), ctx('2.2.2.2'))).status).toBe(400)
    expect((await tts(post('/api/tts', { text: '你'.repeat(201) }), ctx('2.2.2.2'))).status).toBe(400)
  })
  it('picks the requested male/female Mandarin voice and returns audio bytes', async () => {
    process.env.GOOGLE_TTS_API_KEY = 'k'
    const spy = vi.fn(async () => new Response(JSON.stringify({ audioContent: btoa('abc') }), { status: 200 }))
    vi.stubGlobal('fetch', spy)
    const r = await tts(post('/api/tts', { text: '你好', gender: 'male', rate: 0.7 }), ctx('2.2.2.3'))
    expect(r.status).toBe(200); expect(r.headers.get('content-type')).toBe('audio/mpeg')
    const sent = JSON.parse(((spy.mock.calls[0] as unknown as [string, RequestInit])[1]).body as string)
    expect(sent.voice.name).toBe('cmn-CN-Chirp3-HD-Charon'); expect(sent.audioConfig.speakingRate).toBe(0.7)
    expect(new TextDecoder().decode(new Uint8Array(await r.arrayBuffer()))).toBe('abc')
  })
})

describe('Google TTS voice selection', () => {
  it('female and male defaults are different documented Chirp 3 HD voices', () => {
    expect(pickVoice('female', undefined, {})).toBe('cmn-CN-Chirp3-HD-Leda')
    expect(pickVoice('male', undefined, {})).toBe('cmn-CN-Chirp3-HD-Charon')
  })
  it('environment overrides must come from the allow-list; arbitrary voices are ignored', () => {
    expect(pickVoice('male', undefined, { TTS_VOICE_MALE: 'cmn-CN-Chirp3-HD-Orus' })).toBe('cmn-CN-Chirp3-HD-Orus')
    expect(pickVoice('male', undefined, { TTS_VOICE_MALE: 'en-US-Studio-O' })).toBe('cmn-CN-Chirp3-HD-Charon')
    expect(pickVoice('female', 'cmn-CN-Chirp3-HD-Charon', {})).toBe('cmn-CN-Chirp3-HD-Leda') // giọng nam không dùng được cho yêu cầu nữ
    expect(new Set([...VOICES.female, ...VOICES.male]).size).toBe(VOICES.female.length + VOICES.male.length)
  })
  it('retries without speakingRate when the voice rejects it, and reports quota errors', async () => {
    process.env.GOOGLE_TTS_API_KEY = 'k'
    const spy = vi.fn()
      .mockResolvedValueOnce(new Response('{}', { status: 400 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ audioContent: btoa('x') }), { status: 200 }))
    vi.stubGlobal('fetch', spy)
    const ok = await tts(post('/api/tts', { text: '你好', gender: 'female' }), ctx('3.3.3.1'))
    expect(ok.status).toBe(200); expect(spy).toHaveBeenCalledTimes(2)
    expect(JSON.parse(((spy.mock.calls[1] as unknown as [string, RequestInit])[1]).body as string).audioConfig.speakingRate).toBeUndefined()
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{}', { status: 403 })))
    const q = await tts(post('/api/tts', { text: '你好', gender: 'male' }), ctx('3.3.3.2'))
    expect(q.status).toBe(429); expect(await q.json()).toEqual({ error: 'quota_or_permission' })
  })
})
