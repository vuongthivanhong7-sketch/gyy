-- GYY: schema cho Supabase. Dán toàn bộ file này vào SQL Editor rồi bấm Run (có thể chạy lại an toàn).

-- 1. Hồ sơ công khai (chỉ có tên hiển thị; KHÔNG chứa email)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Học viên' check (char_length(display_name) between 2 and 30),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
drop policy if exists "profiles_read" on public.profiles;
create policy "profiles_read" on public.profiles for select using (true);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- Tự tạo hồ sơ khi có người đăng nhập lần đầu. Tên mặc định = tên gọi (từ cuối trong họ tên Google), có thể đổi trong trang "Tôi".
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare nm text;
begin
  nm := left(regexp_replace(trim(coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', '')), '^.*\s', ''), 30);
  insert into public.profiles (id, display_name)
  values (new.id, case when char_length(nm) >= 2 then nm else 'Học viên' end)
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
-- Tạo hồ sơ cho những tài khoản đã tồn tại trước khi chạy file này
insert into public.profiles (id) select id from auth.users on conflict (id) do nothing;

-- 2. Dữ liệu cá nhân: mỗi người chỉ đọc/ghi dòng của chính mình (RLS)
create table if not exists public.progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  idiom_id text not null,
  data jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, idiom_id)
);
create table if not exists public.custom_idioms (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  data jsonb not null,
  primary key (user_id, id)
);
create table if not exists public.activity (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  ts timestamptz not null,
  kind text not null check (kind in ('learn','review','exercise','bonus')),
  points int not null check (points between 0 and 30),
  correct boolean,
  idiom_id text,
  check (ts > now() - interval '7 days' and ts < now() + interval '5 minutes')
);
create index if not exists activity_user_ts on public.activity (user_id, ts);
create index if not exists activity_ts on public.activity (ts);
create table if not exists public.exercise_runs (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  ts timestamptz not null,
  type text not null check (type in ('pairs','match','choice','sentence','cloze','mixed')),
  total int not null check (total between 0 and 100),
  correct int not null check (correct between 0 and 100),
  topic text,
  idiom_ids text[] not null default '{}'
);
create index if not exists runs_user_ts on public.exercise_runs (user_id, ts desc);

do $$ declare t text; begin
  foreach t in array array['progress','custom_idioms','activity','exercise_runs'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "own_select" on public.%I', t);
    execute format('drop policy if exists "own_insert" on public.%I', t);
    execute format('drop policy if exists "own_update" on public.%I', t);
    execute format('drop policy if exists "own_delete" on public.%I', t);
    execute format('create policy "own_select" on public.%I for select using (auth.uid() = user_id)', t);
    execute format('create policy "own_insert" on public.%I for insert with check (auth.uid() = user_id)', t);
    if t in ('progress','custom_idioms') then
      execute format('create policy "own_update" on public.%I for update using (auth.uid() = user_id) with check (auth.uid() = user_id)', t);
      execute format('create policy "own_delete" on public.%I for delete using (auth.uid() = user_id)', t);
    end if;
  end loop;
end $$;

-- 3. Cộng đồng: ai cũng đọc được; chỉ chủ bài mới sửa/xóa (kiểm tra ở database, không dựa vào giao diện)
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 5 and 150),
  body text not null check (char_length(body) between 5 and 4000),
  topic text,
  idiom_id text,
  idiom_hanzi text,
  created_at timestamptz not null default now()
);
create table if not exists public.answers (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 2 and 4000),
  created_at timestamptz not null default now()
);
create index if not exists answers_post on public.answers (post_id, created_at);
do $$ declare t text; begin
  foreach t in array array['posts','answers'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "read_all" on public.%I', t);
    execute format('drop policy if exists "insert_own" on public.%I', t);
    execute format('drop policy if exists "update_own" on public.%I', t);
    execute format('drop policy if exists "delete_own" on public.%I', t);
    execute format('create policy "read_all" on public.%I for select using (true)', t);
    execute format('create policy "insert_own" on public.%I for insert with check (auth.uid() = user_id)', t);
    execute format('create policy "update_own" on public.%I for update using (auth.uid() = user_id) with check (auth.uid() = user_id)', t);
    execute format('create policy "delete_own" on public.%I for delete using (auth.uid() = user_id)', t);
  end loop;
end $$;

-- 4. Bảng xếp hạng tuần: tính trong database, chỉ trả tên hiển thị và điểm (không lộ email hay dữ liệu riêng)
create or replace function public.weekly_leaderboard(week_start timestamptz, max_rows int default 20)
returns table (rank bigint, display_name text, points bigint, is_me boolean)
language sql security definer set search_path = public stable as $$
  with totals as (
    select a.user_id, sum(a.points)::bigint as pts
    from public.activity a
    where a.ts >= week_start and a.ts < week_start + interval '7 days'
    group by a.user_id
    having sum(a.points) > 0
  )
  select row_number() over (order by t.pts desc, p.display_name) as rank,
         p.display_name, t.pts as points, (t.user_id = auth.uid()) as is_me
  from totals t join public.profiles p on p.id = t.user_id
  order by t.pts desc, p.display_name
  limit least(greatest(max_rows, 1), 50);
$$;
grant execute on function public.weekly_leaderboard(timestamptz, int) to anon, authenticated;
