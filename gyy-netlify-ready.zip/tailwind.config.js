const c = (v) => `rgb(var(--${v}) / <alpha-value>)`
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: { DEFAULT: c('brand'), strong: c('brand-strong'), soft: c('brand-soft') },
        'on-brand': c('on-brand'),
        ok: { DEFAULT: c('ok'), soft: c('ok-soft') },
        warn: { DEFAULT: c('warn'), soft: c('warn-soft') },
        bad: { DEFAULT: c('bad'), soft: c('bad-soft') },
        page: c('page'),
        card: c('card'),
        ink: c('ink'),
        muted: c('muted'),
        line: c('line'),
        soft: c('soft'),
      },
      fontFamily: {
        sans: ['Nunito', 'Be Vietnam Pro', 'Noto Sans SC', 'Noto Sans CJK SC', 'PingFang SC', 'Microsoft YaHei', 'system-ui', 'sans-serif'],
        han: ['Noto Sans SC', 'Noto Sans CJK SC', 'Noto Serif SC', 'PingFang SC', 'Microsoft YaHei', 'SimHei', 'sans-serif'],
      },
      borderRadius: { xl2: '1.25rem' },
      boxShadow: { card: '0 1px 2px rgb(var(--shadow) / .06), 0 8px 24px -12px rgb(var(--shadow) / .18)' },
    },
  },
  plugins: [],
}
