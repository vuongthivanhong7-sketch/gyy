#!/usr/bin/env python3
"""Tạo từ điển mở rộng (tra cứu chữ Hán ngoài 99 mục) từ CC-CEDICT, giấy phép CC BY-SA 4.0 (© MDBG).
Nguồn: gói PyPI `cepy-dict` (chứa CC-CEDICT). Chia thành các tệp theo chữ đầu của từ giản thể để trình duyệt chỉ tải đúng phần cần.
Chạy:  pip install cepy-dict && python3 scripts/build-ext-dict.py"""
import json, os, re, shutil, collections
import cepy_dict
out = 'public/data/dict'
shutil.rmtree(out, ignore_errors=True); os.makedirs(out)
shards = collections.defaultdict(list)
n = 0
for _, trad, simp, py, defs in cepy_dict.entries():
    if not re.search(r'[\u4e00-\u9fff]', simp): continue
    shards[simp[0]].append([simp, py, [d for d in defs if d]]); n += 1
# Gom các chữ đầu có mã gần nhau thành một tệp (32 mã/tệp) để giảm từ hơn 10.000 tệp xuống khoảng 700 tệp (dễ triển khai lên Netlify).
buckets = collections.defaultdict(list)
for ch, rows in shards.items(): buckets[ord(ch) // 32].extend(rows)
for b, rows in buckets.items():
    rows.sort(key=lambda r: (r[0][0], len(r[0]), r[0]))
    json.dump(rows, open(f'{out}/b{b:x}.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))
head = open(os.path.join(os.path.dirname(cepy_dict.__file__), 'cc-cedict.txt'), encoding='utf8').read(1200)
date = re.search(r'#! date=(\S+)', head)
json.dump({'name': 'CC-CEDICT', 'publisher': 'MDBG', 'license': 'CC BY-SA 4.0', 'licenseUrl': 'https://creativecommons.org/licenses/by-sa/4.0/',
           'url': 'https://www.mdbg.net/chinese/dictionary?page=cc-cedict', 'date': date.group(1) if date else None, 'entries': n, 'shards': len(buckets), 'bucketSize': 32},
          open(f'{out}/_meta.json', 'w', encoding='utf8'), ensure_ascii=False)
print('entries', n, 'files', len(buckets))

# Bản build một file: nén toàn bộ từ điển thành một tệp gzip và mã hóa base64 để nhúng vào trang.
import gzip, base64
bundle = {f[1:-5]: json.load(open(f'{out}/{f}', encoding='utf8')) for f in os.listdir(out) if f.startswith('b') and f.endswith('.json')}
gz = gzip.compress(json.dumps(bundle, ensure_ascii=False, separators=(',', ':')).encode('utf8'), 9)
pass
open('src/data/dictBundle.ts', 'w').write('// Tự sinh bởi scripts/build-ext-dict.py\nexport default "' + base64.b64encode(gz).decode() + '"\n')
print('bundle gz MB', round(len(gz) / 1e6, 2))
