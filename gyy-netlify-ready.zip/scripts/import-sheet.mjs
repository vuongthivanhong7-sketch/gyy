#!/usr/bin/env node
// Chuyển file Excel tổng hợp quán dụng ngữ (mỗi sheet = một cuốn sách) thành:
//   public/data/idioms.json   (kho quán dụng ngữ)
//   public/data/strokes.json  (dữ liệu thứ tự nét để luyện viết, chạy được khi không có mạng)
// Cách dùng:  npm run import-data -- duong-dan/file.xlsx
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import * as XLSX from 'xlsx'
import { pinyin } from 'pinyin-pro'

const require = createRequire(import.meta.url)
const file = process.argv[2]
if (!file) { console.error('Thiếu đường dẫn file. Ví dụ: npm run import-data -- data.xlsx'); process.exit(1) }

const norm = (s) => String(s ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/[^a-z0-9\u4e00-\u9fff]+/g, '')
const clean = (v) => String(v ?? '').replace(/\s+/g, ' ').replace(/^["“”\s]+|["“”\s]+$/g, '').trim()
const HAN = /\p{Script=Han}/u
const hanOnly = (s) => Array.from(s).filter((c) => HAN.test(c)).join('')
const py = (s) => pinyin(s, { toneType: 'symbol', type: 'string', nonZh: 'consecutive' }).replace(/\s+([，。？！、；：”）」])/g, '$1').replace(/([（“「])\s+/g, '$1').replace(/\s+/g, ' ').trim()
const hash = (s) => { let h = 2166136261; for (const c of s) { h ^= c.codePointAt(0); h = Math.imul(h, 16777619) } return (h >>> 0).toString(36) }

// Nhận diện cột theo tên (không phân biệt dấu). Mỗi sheet có thể đặt tên cột hơi khác nhau.
const COLS = {
  hanzi: (n) => n === 'quandungngu',
  exam: (n) => n === 'de' || n.startsWith('vitri'),
  question: (n) => n.startsWith('causo'),
  page: (n) => n.startsWith('sotrang'),
  quote: (n) => n.startsWith('trichdan'),
  literal: (n) => n === 'nghiaden',
  figurative: (n) => n.startsWith('nghiabong'),
  exampleZh: (n) => n.startsWith('vidu'),
  topics: (n) => n === 'chude' || n === 'chudeliendoi',
  image: (n) => n === 'hinhanh' || n === 'anh' || n === 'linkanh',
  imageSource: (n) => n === 'nguonanh' || n === 'trangnguonanh',
  imageLicense: (n) => n === 'giayphepanh' || n === 'banquyenanh',
  exampleVi: (n) => n === 'nghia' || n.startsWith('nghiadich') || n.startsWith('dichnghia'),
}

const wb = XLSX.read(fs.readFileSync(file))
const byHanzi = new Map()
let rowsTotal = 0, rowsSkipped = 0
const report = []

for (const sheetName of wb.SheetNames) {
  const source = sheetName.trim()
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '' })
  const headers = rows.length ? Object.keys(rows[0]) : []
  const map = {}
  for (const [field, test] of Object.entries(COLS)) { const h = headers.find((x) => test(norm(x))); if (h) map[field] = h }
  const unused = headers.filter((h) => !Object.values(map).includes(h))
  report.push({ source, rows: rows.length, missing: Object.keys(COLS).filter((f) => !map[f]), unused })
  if (!map.hanzi) { console.warn(`! Sheet "${source}": không thấy cột "Quán dụng ngữ", bỏ qua cả sheet`); continue }
  const get = (r, f) => (map[f] ? clean(r[map[f]]) : '')

  for (const r of rows) {
    rowsTotal++
    const hanzi = get(r, 'hanzi').replace(/\s+/g, '')
    if (!hanOnly(hanzi)) { rowsSkipped++; continue }
    let it = byHanzi.get(hanzi)
    if (!it) {
      it = { id: `i-${hash(hanzi)}`, hanzi, pinyin: py(hanzi), meaningVi: '', examples: [], occurrences: [], autoFields: ['pinyin'] }
      byHanzi.set(hanzi, it)
    }
    // Nghĩa bóng làm nghĩa tiếng Việt chính; nghĩa đen giữ riêng. Lấy giá trị đầu tiên không rỗng theo thứ tự sheet.
    const fig = get(r, 'figurative'), lit = get(r, 'literal')
    if (fig && !it.figurative) { it.figurative = fig; it.meaningVi = fig }
    if (lit && !it.literal) it.literal = lit
    // Chủ đề: có thể ghi nhiều chủ đề trong một ô (ngăn cách bằng ; , / hoặc xuống dòng). Không tự gán khi ô trống.
    const tp = get(r, 'topics').split(/[;；,，/|]/).map((x) => x.trim()).filter(Boolean)
    if (tp.length) it.topics = [...new Set([...(it.topics ?? []), ...tp])]
    const img = get(r, 'image')
    if (img && /^https?:\/\//i.test(img) && !it.image) { it.image = img; const src = get(r, 'imageSource'), lic = get(r, 'imageLicense'); if (src || lic) it.imageCredit = { ...(src && { sourceUrl: src }), ...(lic && { license: lic }) } }
    const zh = get(r, 'exampleZh')
    if (zh && !it.examples.some((e) => e.zh === zh)) {
      const vi = get(r, 'exampleVi')
      it.examples.push({ zh, pinyin: py(zh), ...(vi ? { vi } : {}) })
    }
    const occ = { source, exam: get(r, 'exam'), question: get(r, 'question'), page: get(r, 'page'), quote: get(r, 'quote') }
    for (const k of Object.keys(occ)) if (!occ[k]) delete occ[k]
    it.occurrences.push(occ)
  }
}

const idioms = [...byHanzi.values()].filter((i) => { if (!i.meaningVi) { console.warn(`! Bỏ "${i.hanzi}": không có nghĩa bóng`); return false } return true })

const out = path.resolve('public/data')
fs.mkdirSync(out, { recursive: true })
fs.writeFileSync(path.join(out, 'idioms.json'), JSON.stringify({ updatedAt: new Date().toISOString(), idioms }))

// Dữ liệu nét chữ cho mọi chữ Hán có trong các quán dụng ngữ
const chars = [...new Set(idioms.flatMap((i) => Array.from(i.hanzi).filter((c) => HAN.test(c))))]
const strokes = {}, noStroke = []
for (const c of chars) {
  try { strokes[c] = JSON.parse(fs.readFileSync(require.resolve(`hanzi-writer-data/${c}.json`), 'utf8')) } catch { noStroke.push(c) }
}
fs.writeFileSync(path.join(out, 'strokes.json'), JSON.stringify(strokes))

console.log(`Đã đọc ${wb.SheetNames.length} sheet, ${rowsTotal} dòng (bỏ ${rowsSkipped} dòng không có chữ Hán).`)
for (const r of report) console.log(`  • ${r.source}: ${r.rows} dòng${r.missing.length ? ` | thiếu cột: ${r.missing.join(', ')}` : ''}${r.unused.length ? ` | cột chưa dùng: ${r.unused.join(', ')}` : ''}`)
console.log(`\n→ ${idioms.length} quán dụng ngữ (đã gộp các dòng trùng), ${idioms.reduce((n, i) => n + i.examples.length, 0)} câu ví dụ, ${idioms.reduce((n, i) => n + i.occurrences.length, 0)} lần xuất hiện trong đề.`)
console.log(`→ Dữ liệu thứ tự nét: ${Object.keys(strokes).length}/${chars.length} chữ${noStroke.length ? ` (thiếu: ${noStroke.join(' ')})` : ''}`)
console.log('→ Pinyin được tạo tự động (pinyin-pro) vì file chưa có cột pinyin; nên rà lại các từ đa âm.')
