import { parse } from '@babel/parser'
import fs from 'node:fs'
import path from 'node:path'
const VI = /[ăâđêôơưàáạảãằắặẳẵầấậẩẫèéẹẻẽềếệểễìíịỉĩòóọỏõồốộổỗờớợởỡùúụủũừứựửữỳýỵỷỹĂÂĐÊÔƠƯ]|^(Học|Luyện|Tra|Sổ|Chưa|Đã|Không|Xem|Lưu|Hủy|Tôi|Bắt|Nhập|Tìm|Gõ|Nối|Chọn|Xóa|Thêm|Sửa|Mở|Đóng|Ôn|Tiếp|Thống|Tiến|Lịch|Điểm|Bảng|Hỏi|Khó|Tốt|Dễ|Tất|Cảm|Công|Giao|Quan|Thời|Tiền|Tính|Đời)\b/
const SKIP = ['Admin.tsx', 'ImageEditor.tsx', 'demo.ts', 'i18n/', '.test.']
const files = []
const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); fs.statSync(p).isDirectory() ? walk(p) : /\.tsx?$/.test(f) && !SKIP.some((s) => p.includes(s)) && files.push(p) } }
walk('src')
const keys = new Map()
const add = (t) => { t = t.replace(/\s+/g, ' ').trim(); if (t && VI.test(t) && !keys.has(t)) keys.set(t, keys.size) }
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8')
  let ast; try { ast = parse(src, { sourceType: 'module', plugins: ['typescript', 'jsx'] }) } catch { continue }
  const visit = (node, parent) => {
    if (!node || typeof node.type !== 'string') return
    if (node.type === 'JSXText') add(node.value)
    else if (node.type === 'StringLiteral' && parent?.type !== 'ImportDeclaration') add(node.value)
    else if (node.type === 'TemplateLiteral') add(node.quasis.map((q, i) => q.value.cooked + (i < node.quasis.length - 1 ? '{' + i + '}' : '')).join(''))
    for (const k of Object.keys(node)) { const v = node[k]; if (Array.isArray(v)) v.forEach((c) => visit(c, node)); else if (v && typeof v.type === 'string') visit(v, node) }
  }
  visit(ast.program, null)
}
fs.writeFileSync('/tmp/keys.json', JSON.stringify([...keys.keys()], null, 0))
console.log(keys.size)
