// Bọc chuỗi giao diện tiếng Việt trong t()/tx() và chèn const { t, tx } = useI18n(). Chạy: node scripts/i18n-codemod.mjs file1.tsx file2.tsx …
import fs from 'node:fs'
import { createRequire } from 'node:module'
const ts = createRequire(import.meta.url)('/tmp/tsold/node_modules/typescript')

const VI = /[ạảãàáâấầẩẫậăắằẳẵặẹẻẽèéêếềểễệỉịọỏõòóôốồổỗộơớờởỡợụủũùúưứừửữựỳỵỷỹđĐ]/i
const LETTER = /[A-Za-zÀ-ỹ]/
const norm = (s) => s.replace(/\s+/g, ' ').trim()
const keys = new Set()

function eligibleString(n) {
  if (!(ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n))) return false
  return VI.test(n.text)
}
function skipContext(n) {
  const p = n.parent
  if (!p) return true
  if (ts.isCallExpression(p) && ts.isIdentifier(p.expression) && (p.expression.text === 'tr' || p.expression.text === 'trx')) return true
  if (ts.isImportDeclaration(p) || ts.isExportDeclaration(p) || ts.isLiteralTypeNode(p) || ts.isPropertyAssignment(p) && p.name === n) return true
  if (ts.isJsxAttribute(p) && ['className', 'key', 'to', 'href', 'type', 'role', 'id', 'name', 'htmlFor', 'list', 'lang'].includes(p.name.getText())) return true
  if (ts.isBinaryExpression(p) && ['===', '!==', '==', '!='].includes(p.operatorToken.getText())) return true
  if (ts.isElementAccessExpression(p)) return true
  return false
}
function enclosingTop(n) {
  // hàm ngoài cùng ở mức module (component hoặc hook)
  let top = null
  for (let c = n; c; c = c.parent) {
    if ((ts.isFunctionDeclaration(c) || ts.isArrowFunction(c) || ts.isFunctionExpression(c)) && c.parent && (ts.isSourceFile(c.parent) || ts.isVariableDeclaration(c.parent) && ts.isSourceFile(c.parent.parent?.parent) || ts.isExportAssignment(c.parent))) top = c
    if (ts.isSourceFile(c)) break
  }
  return top
}

function pass1(src, file) {
  const sf = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)
  const edits = []
  const eligibleTemplate = (n) => ts.isTemplateExpression(n) && (VI.test(n.head.text) || n.templateSpans.some((s) => VI.test(s.literal.text)))
  const hasEligibleDesc = (n) => { let f = false; const v = (x) => { if (f) return; if (x !== n && !skipContext(x) && (eligibleString(x) || eligibleTemplate(x))) { f = true; return } ts.forEachChild(x, v) }; ts.forEachChild(n, v); return f }
  const visit = (n) => {
    if (skipContext(n) === false && enclosingTop(n)) {
      if (eligibleString(n)) {
        const k = norm(n.text); keys.add(k)
        const q = JSON.stringify(n.text)
        const isAttr = ts.isJsxAttribute(n.parent)
        edits.push([n.getStart(), n.getEnd(), isAttr ? `{tr(${q})}` : `tr(${q})`]); return
      }
      if (eligibleTemplate(n) && !hasEligibleDesc(n)) {
        let tpl = n.head.text; const args = []
        n.templateSpans.forEach((s, i) => { tpl += `{${i}}` + s.literal.text; args.push(s.expression.getText()) })
        keys.add(tpl)
        edits.push([n.getStart(), n.getEnd(), `tr(${JSON.stringify(tpl)}, [${args.join(', ')}])`]); return
      }
    }
    ts.forEachChild(n, visit)
  }
  visit(sf)
  return apply(src, edits)
}

function apply(src, edits) {
  edits.sort((a, b) => b[0] - a[0])
  let out = src
  for (const [s, e, r] of edits) out = out.slice(0, s) + r + out.slice(e)
  return { out, changed: edits.length }
}

function pass2(src, file) {
  const sf = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)
  const edits = []
  const visit = (n) => {
    if ((ts.isJsxElement(n) || ts.isJsxFragment(n)) && enclosingTop(n)) {
      const kids = n.children
      let seg = []
      const flush = () => {
        if (seg.length === 0) return
        const hasText = seg.some((c) => ts.isJsxText(c) && LETTER.test(c.text))
        if (hasText) {
          let tpl = '', args = [], lead = '', trail = ''
          seg.forEach((c, i) => {
            if (ts.isJsxText(c)) {
              let tx = c.text.replace(/&nbsp;/g, '\u00a0').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
              // JSX: khoảng trắng có xuống dòng ở đầu/cuối bị bỏ; khoảng trắng đơn thuần được giữ
              if (i === 0) { const m = /^[ \t]+(?=\S)/.exec(tx); if (m && !/\n/.test(tx.slice(0, m[0].length))) lead = ' '; tx = tx.replace(/^\s+/, '') }
              if (i === seg.length - 1) { const m = /(?<=\S)[ \t]+$/.exec(tx); if (m) trail = ' '; tx = tx.replace(/\s+$/, '') }
              tpl += tx.replace(/\s*\n\s*/g, ' ')
            } else { // JsxExpression
              const inner = c.expression ? c.expression.getText() : ''
              if (c.expression && ts.isStringLiteral(c.expression) && c.expression.text === ' ') { tpl += ' '; return }
              tpl += `{${args.length}}`; args.push(inner)
            }
          })
          tpl = tpl.replace(/ +/g, ' ')
          const key = tpl.trim()
          if (key && LETTER.test(key.replace(/\{\d+\}/g, ''))) {
            keys.add(key)
            const call = args.length ? `{trx(${JSON.stringify(key)}, [${args.join(', ')}])}` : `{tr(${JSON.stringify(key)})}`
            edits.push([seg[0].getStart(), seg[seg.length - 1].getEnd(), (lead ? "{' '}" : '') + call + (trail ? "{' '}" : '')])
          }
        }
        seg = []
      }
      for (const c of kids) {
        if (ts.isJsxElement(c) || ts.isJsxSelfClosingElement(c) || ts.isJsxFragment(c)) flush()
        else seg.push(c)
        if (ts.isJsxElement(c) || ts.isJsxSelfClosingElement(c) || ts.isJsxFragment(c) || ts.isJsxExpression(c)) visit(c)
      }
      flush()
      if (ts.isJsxElement(n)) ts.forEachChild(n.openingElement, visit)
      return
    }
    ts.forEachChild(n, visit)
  }
  visit(sf)
  // Bỏ các chỉnh sửa lồng nhau (giữ bản ngoài cùng); phần bên trong được xử lý ở lượt sau.
  edits.sort((a, b) => a[0] - b[0] || b[1] - a[1])
  const kept = []; let end = -1
  for (const e of edits) { if (e[0] >= end) { kept.push(e); end = e[1] } }
  return apply(src, kept)
}

function inject(src, file) {
  if (!/\btr\(|\btrx\(/.test(src)) return src
  const sf = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)
  const edits = []
  const tops = new Set()
  const visit = (n) => {
    if (ts.isCallExpression(n) && ts.isIdentifier(n.expression) && (n.expression.text === 'tr' || n.expression.text === 'trx')) { const top = enclosingTop(n); if (top) tops.add(top) }
    ts.forEachChild(n, visit)
  }
  visit(sf)
  for (const fn of tops) {
    const names = new Set()
    const v2 = (n) => { if (ts.isCallExpression(n) && ts.isIdentifier(n.expression) && ['tr', 'trx'].includes(n.expression.text) && enclosingTop(n) === fn) names.add(n.expression.text); ts.forEachChild(n, v2) }
    v2(fn)
    const map = { tr: 't: tr', trx: 'tx: trx' }
    const decl = `const { ${[...names].sort().map((x) => map[x]).join(', ')} } = useI18n()`
    if (ts.isBlock(fn.body)) edits.push([fn.body.getStart() + 1, fn.body.getStart() + 1, `\n  ${decl}`])
    else edits.push([fn.body.getStart(), fn.body.getEnd(), `{\n  ${decl}\n  return ${fn.body.getText()}\n}`])
  }
  let out = apply(src, edits).out
  if (!/useI18n\b.*from/.test(out)) {
    const rel = file.includes('/pages/') || file.includes('/components/') ? '../i18n' : './i18n'
    const imp = `import { useI18n } from '${rel}'\n`
    const lastImport = [...out.matchAll(/^import .*$/gm)].pop()
    out = lastImport ? out.slice(0, lastImport.index + lastImport[0].length) + '\n' + imp.trimEnd() + out.slice(lastImport.index + lastImport[0].length) : imp + out
  }
  return out
}

for (const file of process.argv.slice(2)) {
  let src = fs.readFileSync(file, 'utf8')
  let total = 0
  for (let i = 0; i < 4; i++) { const r = pass1(src, file); src = r.out; total += r.changed; if (!r.changed) break }
  for (let i = 0; i < 6; i++) { const r2 = pass2(src, file); src = r2.out; total += r2.changed; if (!r2.changed) break }
  src = inject(src, file)
  fs.writeFileSync(file, src)
  console.log(file, 'edits', total)
}
fs.writeFileSync('/tmp/i18n-keys.json', JSON.stringify([...keys], null, 1))
console.log('keys', keys.size)
