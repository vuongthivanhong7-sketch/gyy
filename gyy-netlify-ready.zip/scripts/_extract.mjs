import { parse } from '@babel/parser'
import fs from 'node:fs'
import path from 'node:path'
const VI = /[ăâđêôơưàáạảãằắặẳẵầấậẩẫèéẹẻẽềếệểễìíịỉĩòóọỏõồốộổỗờớợởỡùúụủũừứựửữỳýỵỷỹĂÂĐÊÔƠƯ]|^(Học|Luyện|Tra|Sổ|Chưa|Đã|Không|Xem|Lưu|Hủy|Tôi|Bắt|Nhập|Tìm|Gõ|Nối|Chọn|Xóa|Thêm|Sửa|Mở|Đóng|Ôn|Tiếp|Thống|Tiến|Lịch|Điểm|Bảng|Hỏi)\b/
const files = []
const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); fs.statSync(p).isDirectory() ? walk(p) : /\.tsx?$/.test(f) && !/\.test\./.test(f) && files.push(p) } }
walk('src')
const out = {}; let total = 0; const uniq = new Set()
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8')
  let ast; try { ast = parse(src, { sourceType: 'module', plugins: ['typescript', 'jsx'] }) } catch (e) { console.error('parse fail', f, e.message); continue }
  let n = 0
  const visit = (node, parent) => {
    if (!node || typeof node.type !== 'string') return
    if (node.type === 'JSXText') { const t = node.value.replace(/\s+/g, ' ').trim(); if (t && VI.test(t)) { n++; uniq.add(t) } }
    else if (node.type === 'StringLiteral' && VI.test(node.value) && parent?.type !== 'ImportDeclaration' && !(parent?.type === 'CallExpression' && ['t','tx'].includes(parent.callee?.name) && parent.arguments[0] === node)) { n++; uniq.add(node.value) }
    else if (node.type === 'TemplateLiteral' && !(parent?.type === 'CallExpression' && ['t','tx'].includes(parent.callee?.name))) { const t = node.quasis.map((q) => q.value.cooked).join('{}'); if (VI.test(t)) { n++; uniq.add(t) } }
    for (const k of Object.keys(node)) { const v = node[k]; if (Array.isArray(v)) v.forEach((c) => visit(c, node)); else if (v && typeof v.type === 'string') visit(v, node) }
  }
  visit(ast.program, null); if (n) { out[f.replace('src/', '')] = n; total += n }
}
console.log(out); console.log('TOTAL occurrences', total, 'unique', uniq.size)
