#!/usr/bin/env python3
"""Gộp kết quả OCR tiêu đề mục từ của 3 từ điển thành public/data/dict-index.json.
Đầu vào: /tmp/ocr/out/{xd,ys,cy}.jsonl (do ocr_dicts.py tạo). Số trang in được suy ra từ trang PDF khi OCR đọc sai số."""
import json, re, datetime, statistics, sys
from collections import Counter
HAN = re.compile(r'[\u4e00-\u9fff]')
han = lambda s: ''.join(HAN.findall(s))
entries, pages, stats = [], {}, {}
for did in ('xd', 'cy', 'ys'):
    try: rows = [json.loads(l) for l in open(f'/tmp/ocr/out/{did}.jsonl', encoding='utf8')]
    except FileNotFoundError: rows = []
    rows.sort(key=lambda r: r['p'])
    pages[did] = len(rows)
    # Suy ra độ lệch (trang PDF - số trang in) bằng số trung vị của các trang đọc được số.
    diffs = [r['p'] - int(r['pp']) for r in rows if r.get('pp') and r['pp'].isdigit() and r.get('heads')]
    off = statistics.median(diffs) if diffs else None
    stats[did] = {'pages': len(rows), 'offset': off, 'agree': (sum(1 for d in diffs if d == off) / len(diffs)) if diffs else 0}
    seen = set()
    for r in rows:
        pp = None
        if off is not None and r.get('heads'):
            pp = str(int(r['p'] - off))
            if int(pp) <= 0: pp = None
        for h in r.get('heads', []):
            t, l = h['t'], h.get('l')
            m = re.search(r'[（(〈<《\[【]([谚俗惯])[）)〉>》\]】]?$', t)
            if m: l = l or m.group(1); t = t[:m.start()]
            t = t.strip('，,、；;：: ')
            if len(han(t)) < 2 or '【' in t or '】' in t or len(t) > 45: continue
            key = (t, r['p'])
            if key in seen: continue
            seen.add(key)
            e = {'d': did, 't': t, 'p': r['p']}
            if l: e['l'] = l
            if pp: e['pp'] = pp
            entries.append(e)
out = {'generatedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'), 'pages': pages, 'entries': entries}
json.dump(out, open('/home/claude/gyy/public/data/dict-index.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))
print('entries', Counter(e['d'] for e in entries), 'pages', pages)
print('page-number stats', stats)
print('ys labels', Counter(e.get('l') for e in entries if e['d'] == 'ys'))
