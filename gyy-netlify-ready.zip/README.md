# GYY – Học Quán dụng ngữ HSK 5

React + TypeScript + Vite + Tailwind, Supabase (đăng nhập Google + database), Recharts, hanzi-writer.

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # kiểm thử SRS, chuẩn hóa pinyin, streak
npm run build      # kiểm tra TypeScript + build ra thư mục dist (đưa lên hosting)
npm run build:single  # build thành MỘT file HTML (dist-single/index.html), dữ liệu nhúng sẵn
npm run import-data -- file.xlsx   # nạp dữ liệu từ Google Sheets đã tải về
```

Không có `.env.local` = chế độ thử nghiệm (lưu trên trình duyệt). Xem **HUONG_DAN_CAU_HINH.md** để bật tài khoản thật.

## Cấu trúc
- `src/data/` kho Quán dụng ngữ (đọc `public/data/idioms.json`, có dữ liệu minh họa được gắn nhãn)
- `src/store/` đăng nhập, dữ liệu cá nhân, lớp lưu trữ (`repo.ts`: thiết bị hoặc Supabase)
- `src/lib/` SRS, múi giờ Asia/Ho_Chi_Minh và streak, chuẩn hóa văn bản, phát âm
- `src/pages/` các trang; `exercises.tsx` chứa 5 dạng bài tập
- `supabase/schema.sql` bảng + quy tắc phân quyền (RLS)

## Quản trị
`/quan-tri` (không có trong menu): chủ đề, hình minh họa, kiểm chứng Quán dụng ngữ, xuất/nhập `overrides.json` và `verifications.json`. Xem HUONG_DAN_CAU_HINH.md.
